---
name: 'Question'
about: 'Questions and requests for support'
title: 'PLEASE DO NOT USE GITHUB FOR QUESTIONS - CHECK FAQ OR USE FORUM'
labels: 'declined: question :x:'
assignes:

---

https://www.jacoco.org/jacoco/trunk/doc/faq.html

https://groups.google.com/forum/?fromgroups=#!forum/jacoco

Thank you!
